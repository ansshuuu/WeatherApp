//
//  ViewController.swift
//  CalculatorApp
//
//  Created by Ashu Sharma on 11/02/25.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var ResultLabel: UILabel!
    var  numberonTheScreen: Double = 0
    var previousNumber: Double = 0
    var Opreater = 0
    var isPerformingOperation = true
   
    override func viewDidLoad() {
        super.viewDidLoad()
        ResultLabel.text = "0"
    }

    @IBAction func NumberButtonPressed(_ sender: UIButton) {
        let tag = sender.tag
        if isPerformingOperation == true{
            isPerformingOperation = false
            ResultLabel.text = String(tag - 1)
            numberonTheScreen = Double(ResultLabel.text!)!
        }else{
            if ResultLabel.text == "0" {
                ResultLabel.text = String(tag - 1)
                numberonTheScreen = Double( ResultLabel.text!)!
            }else {
                ResultLabel.text = ResultLabel.text! +  String(tag - 1)
                numberonTheScreen = Double( ResultLabel.text!)!
            }
            
        }
     
    }
    
    @IBAction func OpreaterButtonPressed(_ sender: UIButton) {
        let tag = sender.tag
        if tag == 16{
            ResultLabel.text = ""
            previousNumber = 0
            numberonTheScreen = 0
            Opreater = 0
            return ResultLabel.text = "0"
        }
        if tag == 17 {
            var clearText = String((ResultLabel.text ?? "").dropLast())
            
            ResultLabel.text = clearText == "" ? "0" : clearText
            
            numberonTheScreen -= 1
            
        }
        
        if tag == 11{
            isPerformingOperation = true
            previousNumber = Double(ResultLabel.text!) ?? .zero
            ResultLabel.text = "÷"
            Opreater = tag
            }else if tag == 12 {
            isPerformingOperation = true
            previousNumber = Double(ResultLabel.text!) ?? .zero
            ResultLabel.text = "*"
                Opreater = tag
         
            
        }else if tag == 13 {
            isPerformingOperation = true
            previousNumber = Double(ResultLabel.text!) ?? .zero
            ResultLabel.text = "-"
            Opreater = tag
            
            
        }else if tag == 14 {
            isPerformingOperation = true
            previousNumber = Double(ResultLabel.text!) ?? .zero
            ResultLabel.text = "+"
            Opreater = tag
            
        }else if tag == 15 {
            
            if Opreater == 11 {
                ResultLabel.text = String(previousNumber / numberonTheScreen)
            }else if Opreater == 12 {
                ResultLabel.text = String(previousNumber * numberonTheScreen)
                
            }else if Opreater == 13 {
                ResultLabel.text = String(previousNumber - numberonTheScreen)
                
            }else if Opreater == 14 {
                ResultLabel.text = String(previousNumber + numberonTheScreen)
                
            }
            
        }
        
    }
}
